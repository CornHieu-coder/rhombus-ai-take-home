Rhombus AI scheduled-delivery investigation — project 4266

Read support-report.md first. Times in the report and JSON are UTC.

Main comparisons:
1. Schedule 202 edited to minute 56: API/GCS observations across its future
   trigger boundary, with no manual Run click. JSON and redacted screenshot.
2. Fresh schedule 208, every-minute cron: 14 API/GCS samples, zero executions
   and no new object. The final screenshot is a LATER cleanup snapshot:
   208 paused, 202 restored; it demonstrates that a future Next run renders.
3. Three actual manual baseline outputs under matching runtime configuration:
   control at 13:49 UTC and repeats at 14:35 UTC. The fetched S3 source CSV,
   downloaded GCS CSVs, provenance and independent validator report are here.
   All seven validator checks pass, including ordered determinism.
4. The chatbot suggested disabling sampling; later comparisons still failed.
5. The user later replaced schedules with 209 and tried minute 16. Only a
   short active observation is recorded before the user paused it. Later
   paused samples do not count as additional active trigger coverage.

No execution ID exists in the observed empty histories. These observations
do not prove that a job was dispatched or identify a backend root cause.
Current schedule 209 is paused by the user. Tokens, service-account keys,
authenticated browser state and signed download URLs are not included.

manifest.json gives SHA-256 checksums for each included evidence file.
Repository: https://github.com/CornHieu-coder/rhombus-ai-take-home
